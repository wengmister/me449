# ME449 Final Project - Zhengyang Kris Weng Submission Fall 2024

### Milestone 2:
Created a function `TrajectoryGenerator` to generate the reference trajectory for the end-effector frame `{e}`. This trajectory consists of eight concatenated trajectory segments, as described above. Each trajectory segment begins and ends at rest.

See `code/milestone2.py` for more details.